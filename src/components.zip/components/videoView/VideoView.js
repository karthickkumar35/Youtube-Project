import React, { useState } from 'react'
import './VideoView.scss';
import { Icon } from '@iconify/react';
import { TextField } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { forms } from '../Redux/stateSlice';

let task=[];
const VideoView = () => {
    const state = useSelector(({sample})=> sample);
     const dispatch = useDispatch();

     const [inpName,setName]=useState();
     const inputName=(e)=>{
        setName(e.target.value)
   }
    const sub=(e)=>{
        e.preventDefault();
          const setof=inpName;
           task.push(setof);
          console.log("task",task)
    }
  return (
    <div>
      <div className='video-contant'>
        <h1 className='videoName'>PONNIYIN SELVAN-2 | PUBLIC REVIEW |</h1>
        <p className='videoHastag'>#ponniyinselvan</p>
        <div className='videoChennal'>
            <div className='leftVideoChennal'>
                <div className='chennalmg'>
                    <img src={require("./images/1.jfif")}></img>
                </div>
                <div className='chennalName'>
                    <p id='chennalTitle'>Tamil Movies</p>
                    <p className='chennalSub'>200k subscribers</p>
                </div>
                <button className='sub-btn'>subscribe</button>
            </div>
            <div className='rightVideoChennal'>
                <div className='videoLike'>
                    <Icon className='videoIcons' icon="bx:like" />
                    <span Id='likeCount'></span>
                    <Icon className='videoIcons' icon="bx:dislike" />
                </div>
                <div className='videoShare'>
                    <Icon className='videoIcons' icon="ph:share-fat" />
                    <p className='videoIconsname'>Share</p>
                </div>
                <div className='videoClip'>
                    <Icon className='videoIcons' icon="clarity:scissors-line" />
                    <p className='videoIconsname'>Clip</p>
                </div>
                <div className='videoEtc'>
                    <Icon className='videoIcons' icon="mdi:dots-horizontal" />
                </div>
            </div>
        </div>
        <div className='comment-sec'>
            <div className='comment-title'>
                <p className='com-head'>Comments</p>
                <div className='com-filter'>
                    <Icon className='filterIcon' icon="material-symbols:sort-rounded" />
                    <p id='comFilterName'>Sort by</p>
                </div>
            </div>
            <div className='com-input'>
                <Icon className='input-img' icon="mdi:user-circle" />
                <form onSubmit={sub}>
                <TextField id="com-pad"  value={inpName} onChange={inputName} variant="standard" />
                <input className="input link1" type={"submit"}></input>
                </form>
            </div>
        </div>
        {task.map((value,index)=>{
            return( <div key={index}
            >
                <h1>{value}</h1>
            </div>)
        })}
      </div>
    </div>
  )
}

export default VideoView
