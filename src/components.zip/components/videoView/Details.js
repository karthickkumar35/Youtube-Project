import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import TextField from '@mui/material/TextField';
import AccountCircle from '@mui/icons-material/AccountCircle';
import DeleteIcon from '@mui/icons-material/Delete';
import ThumbUpOffAltIcon from '@mui/icons-material/ThumbUpOffAlt';
import ThumbUpAltIcon from '@mui/icons-material/ThumbUpAlt';
import ThumbDownOffAltIcon from '@mui/icons-material/ThumbDownOffAlt';
import ThumbDownAltIcon from '@mui/icons-material/ThumbDownAlt';
import Button from '@mui/material/Button';
import ReplyIcon from '@mui/icons-material/Reply';
import DownloadIcon from '@mui/icons-material/Download';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import SortIcon from '@mui/icons-material/Sort';
import './Details.scss';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Stack from '@mui/material/Stack';
import SentimentSatisfiedAltSharpIcon from '@mui/icons-material/SentimentSatisfiedAltSharp';
import { useSelector } from 'react-redux';
import Objects from '../All Data/All-Objects';
// import Button from '@mui/material-next/Button';
import './VideoView.scss';



const Details = () => {

  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  // const video = [
  //   {
  //     image: "https://images.unsplash.com/photo-1575936123452-b67c3203c357?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8&w=1000&q=80",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     description: "226,626 views  18 Apr 2023  #sjsurya #viral #love_whatsapp_statusKadhal 💞Kappal💞iravi whatsapp status | Viral girl whatsapp status | Rakesh_editzkadhal kappal songviral girl dancekadhal kappalinstagram viral dance videoviral dance on instagramkadhal kappal videoinstagram viral reel dance videotum tum song instagram viral songinstagram viral girl nameviral dancesviral dance",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   }
  // ]

  // const video2 = [
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   },
  //   {
  //     image: "https://i.ytimg.com/vi/2pOVz45p8Ho/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDUPjZEPRXGzorX67ni9zGnv1aC2A",
  //     name: "Naam - Adi Penne (Duet) Official Video [4K] - T Suriavelan | Rupiny | Stephen Zechariah ft Srinisha",
  //     icon: "https://yt3.googleusercontent.com/ytc/AGIKgqNvxNlyYDiiSPytCVFFFU9CGgznUJVq28RwjPRoFQ=s176-c-k-c0x00ffffff-no-rj ",
  //     channel: "Think Music",
  //     subscriber: "1.4m",
  //     like: 10,
  //     view: "77k views",
  //     ago: "2 years ago"
  //   }

  // ]

  const Video = useSelector(({ sample }) => sample.files);
  const [state, setState] = useState(Objects);
  const ObjectsVideo = state.filter(e => e.type === Video.type);
  console.log(ObjectsVideo);

  const [videoState, setVideoState] = useState([Video]);

  const oneVideo = (e) => {
    // console.log(e);
    setVideoState([e]);
  }

  return (
    <>
      <div id='details-sec'>
        <div className='details-container'>
          <div className='details-row-1'>
            {videoState.map((val, i) => {
              return <div key={i} id='playVideo'>
                <div className='videodiv'>
                  <video
                            // autoPlay={true}
                            className='details-video'
                            src={val.url}
                            poster={val.thump}
                            controls
                        />
                </div>
                <div className='details-col-2'>
                  <h4>{val.name}</h4>
                </div>
                <div className='details-col-3'>
                  <div className='details-description-1'>
                    <div className='details-channel-icon'>
                      <img className='details-channel' src={(val.logo)} />
                    </div>
                    <div className='details-channel-name'>
                      <h4>{val.name}</h4>
                      <p>Subscribers</p>
                    </div>
                    <div className='details-channel-subscribe'>
                      <button id='subscribe'>subscribe</button>
                    </div>
                  </div>
                  <div className='details-description-2'>
                    <div className='details-like'>
                      <button id='thumbsup'><ThumbUpOffAltIcon /></button>
                      <p id='like-count'>1</p>
                      <button id='thumbsdown'><ThumbDownOffAltIcon /></button>
                    </div>
                    <div className='details-share'>
                      <button id='share'>
                        <ReplyIcon />Share
                      </button>
                    </div>
                    <div className='details-download'>
                      <button id='download'>
                        <DownloadIcon />Download
                      </button>
                    </div>
                    <div className='details-extra'>
                      <button id='extra'>
                        <MoreHorizIcon />
                      </button>
                    </div>
                  </div>
                </div>
                <div className='details-col-4'>
                  <div className='details-video-description'>
                    <p>Hello</p>
                  </div>
                </div>
                <div className='details-col-5'>
                  <div className='details-comment-count'>
                    <div className='comment-count'>
                      <p>50 Comments</p>
                    </div>
                    <div className='comment-sort'>
                      <SortIcon />Sort
                    </div>
                  </div>
                  <div className='details-comment'>
                    <Box sx={{ display: 'flex', alignItems: 'flex-end' }}>
                      <AccountCircle sx={{ color: 'action.active', mr: 1, my: 0.5 }} />
                      <TextField style={{ width: "100%" }} id="input-with-sx" label="Add a Comment" variant="standard" />
                    </Box>
                  </div>
                  <div className='comment-btn-row'>
                    <div className='comment-icon'>
                      <div className='comment-smile'>
                        <SentimentSatisfiedAltSharpIcon />
                      </div>
                      <div className='comment-para'>
                        <p>By completing this action you are creating a <span>​channel</span> and agree to <span>​YouTube's Terms of Service</span>​.</p>
                      </div>
                    </div>
                    <div className='comment-btn'>
                      <div className='comment-cancel'>
                        <Button
                          color="secondary"
                          disabled={false}
                          size="small"
                          variant="filledTonal"
                          value="cancel"
                        >cancel</Button>
                      </div>
                      <div className='comment-ok'>
                        <Button
                          color="secondary"
                          disabled={false}
                          size="small"
                          variant="filledTonal"
                          value="cancel"
                        >Comment</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            })}

          </div>
          <div className='details-row-2'>
            <div id='details-filterbar'>
              <Stack className='filterbar-row' spacing={2} direction="row">
                <Tabs
                  value={value}
                  onChange={handleChange}
                  variant="scrollable"
                  scrollButtons
                  allowScrollButtonsMobile
                  aria-label="scrollable force tabs example">
                  <Tab className='filterbar-btn' label="All" />
                  <Tab className='filterbar-btn' label="Mixes" />
                  <Tab className='filterbar-btn' label="Music" />
                  <Tab className='filterbar-btn' label="Animated films" />
                  <Tab className='filterbar-btn' label="Bikes" />
                  <Tab className='filterbar-btn' label="Cars" />
                  <Tab className='filterbar-btn' label="Cartoons" />
                  <Tab className='filterbar-btn' label="Cooking" />
                  <Tab className='filterbar-btn' label="Games" />
                  <Tab className='filterbar-btn' label="News" />
                  <Tab className='filterbar-btn' label="Smart phones" />
                  <Tab className='filterbar-btn' label="TNPSC" />
                </Tabs>
              </Stack>
            </div>
            {ObjectsVideo.map((value, i) => {
              return <div key={i} className='details-card-2' onClick={() => oneVideo(value)}>
                <div className='details-right-video'>
                  <img className='details-right-image' src={(value.thump)} />
                </div>
                <div className='details-right-description'>
                  <div className='details-name'>
                    <h4>{value.name}</h4>
                  </div>
                  <div className='details-channel'>
                    <p>Channel Name</p>
                  </div>
                  <div className='details-content'>
                    <div className='details-view'>
                      <h5>View</h5>
                    </div>
                    <div className='details-ago'>
                      <h5>Ago</h5>
                    </div>
                  </div>
                </div>
              </div>
            }
            )}
          </div>
        </div>
      </div>
    </>
  )
}

export default Details
